<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'custom_id',
        'photo',
        'phone_number',
    ];

    protected $table = 'users';

    // Define the inverse relationship with ProcessedBorrowBooks
    public function processedBorrowBooks()
    {
        return $this->hasMany(processed_borrowbooks::class, 'user_id');
    }
    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

     /**
     * The "booted" method of the model.
     *
     * @return void
     */
    protected static function booted()
    {
        static::creating(function ($user) {
            if (empty($user->custom_id)) {
                $user->custom_id = static::generateCustomId();
            }
        });
    }

    /**
     * Generate a unique 4-digit custom ID.
     *
     * @return string
     */
    protected static function generateCustomId()
    {
        do {
            $customId = Str::upper(Str::random(4));
        } while (static::where('custom_id', $customId)->exists());

        return $customId;
    }
}
