<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.users/>
        </div>

    </div>
</x-admin-layout>
