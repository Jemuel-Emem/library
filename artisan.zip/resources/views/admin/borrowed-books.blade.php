<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.borrowed-books/>
        </div>

    </div>
</x-admin-layout>
