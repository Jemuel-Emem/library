<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.book-returned/>
        </div>

    </div>
</x-admin-layout>
