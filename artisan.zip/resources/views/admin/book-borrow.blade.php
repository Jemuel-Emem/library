<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.book-borrow/>
        </div>

    </div>
</x-admin-layout>
