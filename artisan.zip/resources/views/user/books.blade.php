<x-user-layout>
    <div>

        <div class=" h-screen flex justify-center ">
            <livewire:user.books />
        </div>

    </div>
</x-user-layout>
