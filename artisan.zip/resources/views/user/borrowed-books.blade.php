<x-user-layout>
    <div>

        <div class="  flex justify-center ">
            <livewire:user.borrowed-books />
        </div>

    </div>
</x-user-layout>
