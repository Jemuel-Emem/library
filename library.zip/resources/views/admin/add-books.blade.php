<x-admin-layout>
    <div>

        <div class=" ">
            <livewire:admin.add-books />
        </div>

    </div>
</x-admin-layout>
