<x-user-layout>
    <div>

        <div class=" h-screen flex justify-center w-screen">
            <livewire:user.index />
        </div>

    </div>
</x-user-layout>
