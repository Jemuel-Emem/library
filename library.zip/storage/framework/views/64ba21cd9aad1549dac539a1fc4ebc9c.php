<?php if (isset($component)) { $__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>

        <div class=" h-screen flex justify-center w-screen">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.books', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3081436311-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965)): ?>
<?php $attributes = $__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965; ?>
<?php unset($__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965)): ?>
<?php $component = $__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965; ?>
<?php unset($__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\BorrowingSystem\library\resources\views\user\books.blade.php ENDPATH**/ ?>