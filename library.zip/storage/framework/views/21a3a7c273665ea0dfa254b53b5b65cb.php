<div>
    <div class="p-6 bg-white shadow-md rounded-lg mt-12">
        <h2 class="text-2xl font-semibold mb-4">Borrowed Books List</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $borrowedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowedBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white shadow-lg rounded-lg overflow-hidden">
                    <div class="p-4">
                        <h3 class="text-xl font-semibold mb-2"><?php echo e($borrowedBook->book->title); ?></h3>
                        <p class="text-gray-600 mb-1">ISBN: <?php echo e($borrowedBook->book->isbn); ?></p>
                        <p class="text-gray-600 mb-1">Borrowed By: <?php echo e($borrowedBook->user->name); ?></p>
                        <p class="text-gray-600 mb-1">Borrowed At: <?php echo e($borrowedBook->borrowed_at->format('Y-m-d')); ?></p>
                        <p class="text-gray-600 mb-1">Due Date: <?php echo e($borrowedBook->due_date->format('Y-m-d')); ?></p>
                        <p class="text-gray-600 mb-1">Status: <?php echo e(ucfirst($borrowedBook->status)); ?></p>
                        <!--[if BLOCK]><![endif]--><?php if($borrowedBook->book->image): ?>
                            <img src="<?php echo e(asset('storage/' . $borrowedBook->book->image)); ?>" alt="Book Cover" class="w-full h-48 object-cover">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/150" alt="No Image" class="w-full h-48 object-cover">
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($borrowedBook->qr_code): ?>
                            <img src="<?php echo e(asset('storage/' . $borrowedBook->qr_code)); ?>" alt="QR Code" class="w-32 h-32 object-cover mt-4">
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full text-center text-gray-500">
                    No borrowed books found.
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mt-4">
            <?php echo e($borrowedBooks->links()); ?>

        </div>
    </div>

    <div class="p-6 mt-6">
        <h2 class="text-2xl font-semibold mb-4">QR Code Scanner</h2>
        <video id="camera-stream" style="width: 100%; height: 300px; border: 1px solid #ccc;"></video>
        <button id="capture-button" class="bg-blue-500 text-white py-2 px-4 rounded mt-4">Capture Photo</button>
        <canvas id="canvas" style="display: none;"></canvas>
        <button id="scan-button" class="bg-green-500 text-white py-2 px-4 rounded mt-4">Scan QR Code</button>
        <div id="scan-result" class="mt-4"></div>
        <div id="scanning-status" class="mt-4 text-blue-500"></div> <!-- Scanning status indicator -->
    </div>

    <!-- Load QR Code Scanner library -->
    <script src="https://unpkg.com/@zxing/library@latest"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const captureButton = document.getElementById('capture-button');
            const scanButton = document.getElementById('scan-button');
            const scanResult = document.getElementById('scan-result');
            const scanningStatus = document.getElementById('scanning-status'); // Scanning status element
            const cameraStream = document.getElementById('camera-stream');
            const canvas = document.getElementById('canvas');
            const canvasContext = canvas.getContext('2d');

            let stream;

            // Start camera stream
            navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
                .then(function (mediaStream) {
                    stream = mediaStream;
                    cameraStream.srcObject = mediaStream;
                    cameraStream.play();
                })
                .catch(function (err) {
                    console.error('Error accessing camera:', err);
                    scanResult.innerText = 'Error accessing camera. Please check permissions.';
                });

            // Capture photo
            captureButton.addEventListener('click', function () {
                if (stream) {
                    canvas.width = cameraStream.videoWidth;
                    canvas.height = cameraStream.videoHeight;
                    canvasContext.drawImage(cameraStream, 0, 0, canvas.width, canvas.height);
                    scanResult.innerText = 'Photo captured. Click "Scan QR Code" to process.';
                } else {
                    scanResult.innerText = 'No camera stream available.';
                }
            });

            // Scan QR code
            scanButton.addEventListener('click', function () {
                if (canvas.width && canvas.height) {
                    scanningStatus.innerText = 'Scanning...'; // Indicate scanning is in progress
                    const codeReader = new ZXing.BrowserQRCodeReader();
                    codeReader.decodeFromImage(canvas)
                        .then(result => {
                            scanningStatus.innerText = ''; // Clear scanning status
                            scanResult.innerText = `QR Code Data: ${result.text}`;
                            // Call the Livewire method to fetch the book data
                            window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('fetchBorrowedBook', result.text);
                        })
                        .catch(err => {
                            scanningStatus.innerText = ''; // Clear scanning status
                            console.error('Error scanning QR code:', err);
                            scanResult.innerText = 'Error scanning QR code. Please try again.';
                        });
                } else {
                    scanResult.innerText = 'No image to scan. Please capture a photo first.';
                }
            });
        });
    </script>
</div>
<?php /**PATH D:\laravel\BorrowingSystem\library\resources\views/livewire/admin/book-borrow.blade.php ENDPATH**/ ?>